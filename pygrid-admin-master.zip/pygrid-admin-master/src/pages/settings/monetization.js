import React from 'react'

const Monetization = () => <h1>Monetization</h1>

export default Monetization
