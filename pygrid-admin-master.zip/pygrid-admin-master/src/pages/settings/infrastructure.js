import React from 'react'

const Infrastructure = () => <h1>Infrastructure</h1>

export default Infrastructure
