import React from 'react'

const Branding = () => <h1>Branding</h1>

export default Branding
