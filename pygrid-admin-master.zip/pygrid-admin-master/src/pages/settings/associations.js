import React from 'react'

const Associations = () => <h1>Associations</h1>

export default Associations
