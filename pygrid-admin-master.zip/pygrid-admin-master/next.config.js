module.exports = {
  typescript: {
    ignoreDevErrors: true,
    ignoreBuildErrors: true
  }
}
